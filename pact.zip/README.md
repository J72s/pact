# discord_user_ses_channel_join

discord user hesap ses kanalına girmesi, birden fazla token destekliyor.

"npm i" diyerek modülü yükleyiniz sonra "node app.js" diyerek çalıştırınız, siz çalıştırdıktan sonra kullanıcı hesapları ses kanalına girecektir.  

lütfen ayarlar.json dosyasını doldurun.

## değişim günlüğü

consol tarafında kullanıcı adlarının gözükmesi eklendi, artık hangi hesapların giriş yaptığını görebileceksiniz.

v2 sürümü ile sesten düşme sorunları minimize edildi.
